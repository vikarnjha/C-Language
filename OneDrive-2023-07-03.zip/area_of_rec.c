#include<stdio.h>
int main()
{
    int length,bredth;
    printf("Enter the length of rectangle ");
    scanf("%d", &length);
    printf("Enter the bredth of rectangle ");
    scanf("%d", &bredth);
    printf("\n Area of rectangle is %d \n ", (length*bredth));
    return 0;
}
