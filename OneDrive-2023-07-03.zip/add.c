//programe to print addition of twor numbes
#include<stdio.h>

void main()
{
   int num1,num2;
   printf("Enter the first number=");
   scanf("%d", &num1);
   printf("Enter second number=");
   scanf("%d", &num2);
   printf("Addition of %d and %d is %d", num1,num2,(num1+num2));
   return 0;
}