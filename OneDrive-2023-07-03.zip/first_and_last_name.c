#include <stdio.h>
// #include <conio.h>
int main() 
{  char name[25];
   // Dispay a line about you
   printf("Enter your full name ");
   gets(name);
   printf("\nHello %s \n Welcome here!",name);
   // getch();
   return 0;
}