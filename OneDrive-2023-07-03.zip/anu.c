#include<stdio.h>
// #include<conio.h>
void main()
{
    int num1,num2,total;
    printf("enter first number");
    scanf("%d",&num1);
    printf("enter second number");
    scanf("%d",&num2);
    total = num1 * num2;
    printf("total= %d",total);
    getch();

}