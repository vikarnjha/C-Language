#include <stdio.h>
// #include <conio.h>
int main() 
{  char name[25];
   // Dispay a line about you
   printf("Enter your first name ");
   scanf("%s",&name);
   printf("\n Hey %s \n Welcome here!",name);
   // getch();
   return 0;
}