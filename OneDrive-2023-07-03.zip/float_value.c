#include<stdio.h>
#define PI 3.14
int main()
{
    // int a=8;
    // const float b=7.333;
    // PI = 7.33; cannot do this because PI is a constant
    printf("Value of PI is %.2f",PI);
    // b = 7.22; cannot do this because PI is a constant
    return 0;

}