#include<stdio.h>
#include<conio.h>

int main()
{
    int a = 3;
    float b = (float)54/5;
    printf("The value of b is %.3f and value of a is %d.",b,a);
    return 0;
    
}