#include<stdio.h>

int main()
{
    printf(__DATE__);
    // printf(__TIME__);
    // printf(__FILE__);
    // printf("%d",__LINE__);
    // printf("%d",__STDC__);
    return 0;
}