//Size of a datatype

#include<stdio.h>
int main()
{
    // char sizev;
    printf("%lu", sizeof(int));
    // printf("Enter the datatype you want to know the value of length ");
    // scanf("%s",sizev);
    // printf("The length of datatype is %lu", sizeof(sizev));
    return 0;

}