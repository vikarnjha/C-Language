#include<stdio.h>
int main()
{
    /* code */
    int num;
    printf("Enter the number you want multiplicatiopn of:- ");
    scanf("%d", &num);
    printf("Multiplication table of %d is:- \n",num);
    printf("%d X 1 = %d \n",num, (1*num));
    printf("%d X 2 = %d \n",num, (2*num));
    printf("%d X 3 = %d \n",num, (3*num));
    printf("%d X 4 = %d \n",num, (4*num));
    printf("%d X 5 = %d \n",num, (5*num));
    printf("%d X 6 = %d \n",num, (6*num));
    printf("%d X 7 = %d \n",num, (7*num));
    printf("%d X 8 = %d \n",num, (8*num));
    printf("%d X 9 = %d \n",num, (9*num));
    printf("%d X 10 = %d \n",num, (10*num));
    return 0;
}
