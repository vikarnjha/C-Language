#include<stdio.h>
#include<conio.h>

int main()
{
    int i;
for ( i = 1; i >=1; i++) // || (;;)
{
    printf("Vikarn Jha");
}
    return 0;
}