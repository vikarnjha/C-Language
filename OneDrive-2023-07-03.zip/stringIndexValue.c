#include<stdio.h>
#include<string.h>
int main()
{
    char str[]="Vikarn Jha";
    printf("String length = %d",strlen(str));
    printf("Character at index 3 is = %c",str[3]);
    return 0;

}